<div id="search" class="container-inline">
  <?php print str_replace('Search this site:','',$search_form);?>
</div>
