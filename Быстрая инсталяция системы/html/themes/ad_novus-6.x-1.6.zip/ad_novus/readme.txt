CONTENTS

1. Credits
2. Installation Instructions

--------------------------------------------------------------------------------

1. CREDITS

  Duplika Hosting Solutions <http://www.duplika.com> generously sponsored the 
  porting of this theme from the Wordpress version 'Blueprint'. 

--------------------------------------------------------------------------------

2. INSTALLATION INSTRUCTIONS

  To install this theme simply place the entire ad_novus folder in your
  themes directory, located at your_drupal_site/sites/all/themes (create this 
  directory if it does not already exist).  Then log into your Drupal site with 
  any account that has sufficient privileges to administrate themes and head to 
  the theme configuration page by Administer->Site Building->Themes. Tick the 
  "Enabled" check box next to whichever of the two versions you want enabled 
  (AD Novus Fixed being a set width on all browsers, and AD Novus Fluid 
  changing width depending on your screen size) and then make one of these default
  if you wish.
