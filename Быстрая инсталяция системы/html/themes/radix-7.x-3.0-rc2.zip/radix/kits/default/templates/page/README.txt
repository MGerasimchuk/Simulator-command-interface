
This directory should be used to place page template files.
