
This directory should be used to place field template files.
