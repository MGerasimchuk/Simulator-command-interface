
This directory should be used to place Panels Layouts.
