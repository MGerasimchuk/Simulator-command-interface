/**
 * @file
 * Custom scripts for theme.
 */
(function ($) {
  // code here
})(jQuery);
