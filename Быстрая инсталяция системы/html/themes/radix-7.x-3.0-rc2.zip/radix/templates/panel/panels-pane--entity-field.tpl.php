<?php
/**
 * @file
 * Template for panels pane entity field.
 */
?>
<div class="<?php print $classes; ?>" <?php print $id; ?>>
  <?php print render($content); ?>
</div>
